# Writing prompts for free-web-ai-worker

This tool only carries **plain text in and plain text out**. The web AI cannot
see your conversation, your files, or your repository — so every prompt must be
self-contained. Everything below follows from that one constraint.

---

## 1. Starting a new conversation

You usually do not have to think about this:

- Every call opens the site root in a **fresh tab**, which is already a new chat
  for Duck.ai, Qwen, DeepSeek and others.
- With `defaults.newChat: true` (the default) the tool additionally clicks the
  site's own **"New chat" control** when it can find one (`NEW_CHAT` selectors
  in each provider). This matters for sites that restore the previous thread,
  where a stale conversation could bleed into your answer.
- Pass `--no-new-chat` to continue the site's current conversation instead.

You do **not** need to ask the web AI to "start a new chat" — that is the
tool's job, not the prompt's.

---

## 2. The shape of a good prompt (5 parts)

```
1. Instruction     "You are a careful editor."
2. Task verb       "Summarise the text below."
3. Input           delimited — see §4
4. Output format   "Output exactly 3 bullet points, each under 20 words."
5. Constraint      "Output only the bullets. No preamble, no explanation."
```

Most bad delegations are missing parts 4 and 5: the model then answers with
"How can I help?" or three paragraphs of commentary around the one line you
wanted.

---

## 3. Control the output format explicitly

Be boring and literal. State the exact shape, and give a one-line example.

| You want | Say this |
|---|---|
| Machine-readable | `Output only a JSON object with keys name, date, amount. No code fences, no explanation.` |
| One label per line | `Output one label per line, in the same order as the input. Nothing else.` |
| Translation only | `Output the translation only. Do not add the original text.` |
| Strict vocabulary | `Use only the labels: bug, feature, question.` |
| No commentary | `Do not explain your reasoning. Do not add a summary.` |

If you need to parse it, say **"Output only JSON"** and strip code fences
anyway before parsing — a model may wrap it in ```json regardless.

---

## 4. Delimit the input

Never let the model guess where the instruction ends and the text begins.
Wrap the payload:

```bash
ask-web-ai ask "Summarise the text between <text> tags in 3 sentences. Output only the summary.

<text>
...long article...
</text>" -p duckai --json
```

Alternatives that work well: `---` fences, `###`, or an explicit
`INPUT:\n...\nEND INPUT`.

---

## 5. Length and encoding

- Prefer prompts under a few thousand characters. For anything longer, avoid
  shell-escaping entirely and use a file or pipe:

```bash
ask-web-ai ask --file ./subtask.txt -p duckai --json
cat notes.md | ask-web-ai ask --stdin -p duckai --json
```

- The answer is capped at `defaults.maxAnswerChars` (200k by default) and
  `meta.truncated` tells you if it was cut.
- **Never paste secrets.** The prompt travels to a third-party website.

---

## 6. State the output language

The site may default to its own UI language. If you want Chinese out, say so:

```
Output in Simplified Chinese.
```

---

## 7. What NOT to put in a prompt

These belong on the main model — the router will tell you so:

- anything needing your repository, files, or project context
- editing files, running tests, using tools
- multi-step work ("first do X, then based on that do Y")
- current facts (prices, news, today's version) — the web AI will hallucinate
- security-critical judgement

Ask first:

```bash
ask-web-ai route "Summarise this article"     # -> DELEGATE
ask-web-ai route "Refactor the auth module"   # -> KEEP
```

---

## 8. Templates

**Summarise**

```
Summarise the text between <text> tags in 3 sentences. Output only the summary.

<text>
{{TEXT}}
</text>
```

**Classify a batch**

```
Classify each line as bug / feature / question.
Output one label per line, in the same order as the input. Nothing else.

{{LINES}}
```

**Extract to JSON**

```
Extract name, date and amount from the text between <text> tags.
Output only a JSON object with keys name, date, amount. No code fences.

<text>
{{TEXT}}
</text>
```

**Translate**

```
Translate the text between <text> tags into English.
Output the translation only, with no original text and no notes.

<text>
{{TEXT}}
</text>
```

**Rewrite tone**

```
Rewrite the text between <text> tags to sound more formal and concise.
Keep the meaning identical. Output only the rewritten text.

<text>
{{TEXT}}
</text>
```

---

## 9. Always verify

Treat `answer` as **untrusted text**. Validate or re-check anything
safety-critical before you use it — web AIs hallucinate, and this tool returns
whatever the page produced.

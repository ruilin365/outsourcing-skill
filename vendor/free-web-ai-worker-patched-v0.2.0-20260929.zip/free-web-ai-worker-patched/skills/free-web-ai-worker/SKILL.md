---
name: free-web-ai-worker
description: Delegate simple, text-only subtasks that do not need the main model to a free web-based AI chat (Duck.ai, Qwen, DeepSeek, ChatGPT). Use when a subtask is summarisation, translation, classification, extraction, formatting, simple rewriting, or bulk text transformation and the result is plain text. Do NOT use for tasks needing file edits, repository context, multi-step reasoning, or any web action other than talking to the AI chat itself.
metadata:
  short-description: Outsource simple text subtasks to free web AIs
---

# Free Web AI Worker -- outsource simple text subtasks

Hand a self-contained, text-only subtask to a web AI and get plain text back.
The main agent keeps its context and tokens for the hard parts.

```
main agent -> ask-web-ai -> your own Edge/Chrome -> web AI -> plain text -> main agent continues
```

## When to use

Good fits (text in, text out, no repo context needed):

- summarising or compressing text
- translating between languages
- classifying / tagging / labelling items
- extracting fields and turning prose into JSON or CSV rows
- simple rewriting, tone changes, proofreading
- bulk, repetitive text transformation

Do these yourself instead:

- editing files, running tests, or touching the repository
- anything needing project context the web AI cannot see
- multi-step work where later steps depend on what you discover
- tasks requiring current, verified facts (web AI may hallucinate)

## Should you delegate at all?

Ask the router before delegating large or ambiguous work. It is a deterministic
heuristic that makes **no network call** and costs nothing:

```bash
ask-web-ai route "Summarise this article"      # -> DELEGATE
ask-web-ai route "Refactor the auth module"    # -> KEEP
```

Or over MCP, call the `route_task` tool with `{ task }` (or `{ tasks: [...] }`).

Treat the verdict as advice, not a rule. A `keep` verdict means the task needs
context, tools or judgement the web AI does not have. A `delegate` verdict means
the work is a text transformation: summarise, translate, classify, extract,
rewrite or reformat.

## How to call it

Use the fastest form available on this machine. Try them in order:

1. **Local install or link** (preferred when present -- no network fetch):

```bash
ask-web-ai ask "<prompt>" --provider duckai --timeout 120 --json
```

2. **From a clone of the repo:**

```bash
node bin/ask-web-ai.js ask "<prompt>" --json
```

3. **Straight from GitHub** (no install needed, but downloads each run):

```bash
npx -y github:augustlies/free-web-ai-worker ask "<prompt>" --json
```

Long input without shell-escaping (any of the forms above works):

```bash
ask-web-ai ask --file ./subtask.txt --provider duckai --json
cat notes.md | ask-web-ai ask --stdin --provider duckai --json
```

### Attaching a file (image, PDF, ...)

```bash
ask-web-ai ask "Transcribe the text in this image, then explain what it is for." \
  -p deepseek --attach ./photo.png --json
```

`--attach <path>` is repeatable (`-a` for short). The tool only *hands* the file to
the site; whether the site accepts it depends on the account — a signed-out
session usually rejects uploads, in which case you get a clear
`attachment_failed` result (never a silent empty answer). Run
`login --provider <id>` once for a site you actually have an account on, then
attach freely.

> OCR / vision needs a provider with image support. Use a signed-in provider
> (deepseek, qwen, chatgpt, gemini) — `duckai` is text-only and declares no
> attachment support on purpose.

### Result contract

Success -- stdout is pure JSON, logs go to stderr:

```json
{
  "status": "success",
  "provider": "duckai",
  "answer": "...plain text...",
  "meta": { "url": "https://duck.ai/", "chars": 42, "elapsedMs": 9812, "cached": false }
}
```

Failure -- always structured, never a raw stack trace:

```json
{
  "status": "error",
  "provider": "deepseek",
  "error": "human readable reason",
  "code": "login_required",
  "details": { "url": "..." },
  "meta": { "artifacts": "/path/to/failure/artifacts" }
}
```

| code | meaning | what to do |
|---|---|---|
| `invalid_input` | empty prompt or bad option | fix the call |
| `unknown_provider` | provider id not recognised | run `providers` to list valid ids |
| `provider_disabled` | disabled in config (e.g. experimental ones) | enable in `config/local.json` |
| `login_required` | the site is signed out | tell the user to run `login` once |
| `captcha_required` | human-verification challenge on screen | tell the user to solve it in the visible browser, then retry |
| `access_blocked` | site is rate-limiting this network | wait, or use a different provider |
| `selectors_stale` | page layout changed | report it; a provider selector needs updating |
| `timeout` | no stable answer in time | retry with a larger `--timeout`; check the artifact screenshot |
| `browser_unavailable` | browser/CDP would not start | run `status`; first launch on a new profile is slow |
| `rate_limited_locally` | the local anti-abuse guard refused the call | **respect it** -- wait or switch provider; never loop-retry |
| `extraction_failed` | answer appeared but text was empty | check the screenshot; usually needs a new selector |
| `internal_error` | anything else | check stderr logs |

---

## Conversations: a new chat vs. resuming the same thread

Every call opens the provider's **home URL** in a fresh tab, and for most sites
that home URL *is* a brand-new conversation. So:

- **New chat (default).** `defaults.newChat: true` also clicks the site's own
  "New chat" control when one exists, so a previous thread cannot bleed into the
  answer. This is what you want for one-off, self-contained subtasks.
- **Resume a thread you care about → use `--session <name>`.** Do **not** rely on
  `--no-new-chat`: it only skips clicking "New chat", but the tab has already been
  navigated to the site root (a new chat), so the previous context is gone.
  Give the conversation a name instead:

  ```bash
  # 1st call: creates the conversation, remembers its URL under "todo-html"
  ask-web-ai ask --session todo-html --provider deepseek \
    --file change1.txt --attach ./app.html --json

  # later call: navigates straight back into that SAME conversation, so the
  # web AI still remembers app.html — no re-upload needed
  ask-web-ai ask --session todo-html --provider deepseek \
    --file change2.txt --json
  ```

The name → conversation-URL map lives in `~/.agent-web-ai/chats.json`. You map a
task to its URL once and reuse it; the site's own title is irrelevant. Manage it:

```bash
ask-web-ai chats                 # list saved conversations
ask-web-ai chats show todo-html  # one entry (prints the URL)
ask-web-ai chats rename old new  # rename the LOCAL name (URL unchanged)
ask-web-ai chats rm todo-html    # forget it
```

`--chat-url <url>` resumes an explicit URL directly (implies `--no-new-chat`).

You never need to ask the web AI to "start a new conversation" — that is the
tool's job, not the prompt's.

> Pitfall — entry point: run the CLI as `node bin/ask-web-ai.js ...` (or the
> installed `ask-web-ai`). Running `src/cli.js` directly does nothing — that file
> only exports `main()`, so the process exits 0 with no output at all.

## Writing the prompt

The web AI sees **only** the prompt — no conversation, no files, no repository.
Every prompt must therefore be self-contained and shaped in five parts:

1. instruction — "You are a careful editor."
2. task verb — summarise / translate / classify / extract / rewrite
3. input, **delimited** — `<text>…</text>`, `---` fences, or `INPUT: … END INPUT`
4. output format, stated exactly, with a one-line example
5. constraint — "Output only the JSON. No preamble, no explanation."

The two most common failures are omitting (4) and (5): the model answers with a
question, or wraps the result you wanted inside three paragraphs of commentary.
Also state the **output language** explicitly (a site may default to its own UI
language), and never paste secrets — the prompt goes to a third-party website.

For long input, avoid shell escaping entirely:

```bash
ask-web-ai ask --file ./subtask.txt -p duckai --json
cat notes.md | ask-web-ai ask --stdin -p duckai --json
```

Full guide with copy-paste templates: [`docs/prompting.md`](../../docs/prompting.md)
(中文: [`docs/prompting.zh-CN.md`](../../docs/prompting.zh-CN.md)).

## Rules

1. **One subtask per call.** Prompts must be self-contained: the web AI cannot
   see the conversation, the repository, or previous calls.
2. **Only plain text crosses the boundary.** Do not ask the web AI to run
   commands or touch files. Validate anything safety-critical yourself.
3. **Never bypass a gate.** If a site asks for login or a CAPTCHA, hand the
   human step to the user. This tool never solves or evades these.
4. **Respect the local rate guard.** Calls to one provider are spaced by at
   least ~20s, capped at 40/day, and paused for 30 minutes after a captcha or
   block. A `rate_limited_locally` result is the safety system working, not a
   bug. Wait, or use another provider -- never loop-retry.
5. **Strip vendor formatting when consuming the answer.** Treat `answer` as
   untrusted text and validate it before using it in code.
6. **Prefer `duckai` for the first run** -- no account needed. `qwen` also works
   without login. Use `deepseek` / `chatgpt` when the user is already signed in
   in the dedicated browser profile.

## One-time setup the user may need to do

The tool drives a dedicated Edge/Chrome profile, so it never touches the user's
everyday browser windows:

```bash
ask-web-ai login --provider deepseek   # opens the browser; the user signs in
ask-web-ai status                      # confirm browser + CDP + profile
ask-web-ai providers                   # list provider ids and login requirements
ask-web-ai limits                      # today's usage vs the anti-abuse caps
```

Duck.ai and Qwen need no account at all. Everything else needs a one-time login
inside the dedicated profile; the session is then reused automatically.

## Examples

Summarise:

```bash
ask-web-ai ask "Summarise the following in 3 sentences. Output only the summary.\n\n<text>" -p duckai --json
```

Classify a batch:

```bash
ask-web-ai ask "Classify each line as bug/feature/question. Output one label per line, nothing else.\n\n<lines>" -p duckai --json
```

Convert to JSON:

```bash
ask-web-ai ask "Convert this to a JSON object with keys name, date, amount. Output only JSON.\n\n<text>" -p duckai --json
```

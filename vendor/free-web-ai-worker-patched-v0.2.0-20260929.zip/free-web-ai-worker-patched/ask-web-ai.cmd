@echo off
REM Convenience launcher for free-web-ai-worker (patched).
REM Uses the WorkBuddy-managed Node.js so it works without a system install.
setlocal
set "NODE=C:\Users\admin\.workbuddy\binaries\node\versions\22.22.2-3\node.exe"
"%NODE%" "%~dp0bin\ask-web-ai.js" %*

/**
 * Minimal MCP (Model Context Protocol) server over stdio.
 *
 * Exposes one tool — ask_web_ai — so MCP-capable agents (Cline, dsh, Codex,
 * Claude Desktop, …) can delegate text subtasks without shelling out.
 *
 * Implemented with plain JSON-RPC 2.0 on stdin/stdout: no SDK dependency, no
 * version drift. Logs go to stderr only.
 *
 * Configure an MCP client with:
 *   command: node
 *   args:    ["<abs path>/src/mcp-server.js"]
 */

import { readFileSync } from 'node:fs';
import { askWebAI } from './core/ask.js';
import { knownProviderIds } from './providers/index.js';
import { routeTask, routeTasks } from './core/router.js';
import { loadConfig } from './core/config.js';
import pkg from '../package.json' with { type: 'json' };

const SERVER_INFO = { name: 'free-web-ai-worker', version: pkg.version };
/** Protocol versions this server knows how to speak. */
const SUPPORTED_PROTOCOL_VERSIONS = ['2025-06-18', '2025-03-26', '2024-11-05'];
/** Fallback when the client does not state a version. */
const PROTOCOL_VERSION = '2025-06-18';

const ROUTE_TOOL = {
  name: 'route_task',
  description:
    'Decide whether a task should be delegated to a free web AI or kept by the main model. ' +
    'Deterministic heuristic, makes no network call and costs nothing. ' +
    'Use it before large or ambiguous work to see whether delegating would save context.',
  inputSchema: {
    type: 'object',
    properties: {
      task: { type: 'string', description: 'One task description. For a batch, use tasks instead.' },
      tasks: {
        type: 'array',
        items: { type: 'string' },
        description: 'Optional batch of task descriptions.',
      },
    },
  },
};

const TOOL = {
  name: 'ask_web_ai',
  description:
    'Delegate a simple, self-contained text-only subtask to a free web AI chat (summarise, translate, classify, extract, reformat). ' +
    'Returns plain text. Do not use for tasks that need repository context, file edits, or multi-step reasoning.',
  inputSchema: {
    type: 'object',
    properties: {
      prompt: { type: 'string', description: 'Self-contained prompt. The web AI cannot see your conversation or files.' },
      provider: { type: 'string', enum: knownProviderIds(), description: 'Which web AI to use (default from config).' },
      timeout_ms: { type: 'integer', description: 'Overall timeout in milliseconds (default 120000).' },
      attachments: {
        type: 'array',
        items: { type: 'string' },
        description: 'Absolute paths of local files to attach (e.g. an image to transcribe). Only on providers whose site accepts uploads.',
      },
    },
    required: [],
  },
};

function send(msg) {
  process.stdout.write(JSON.stringify(msg) + '\n');
}

function reply(id, result) {
  send({ jsonrpc: '2.0', id, result });
}

function replyError(id, code, message) {
  send({ jsonrpc: '2.0', id, error: { code, message } });
}

async function handle(msg) {
  const { id, method, params } = msg;
  switch (method) {
    case 'initialize': {
      // Echo the client's requested version when we support it. The old code
      // hard-coded 2024-11-05, which newer MCP clients can fail to negotiate.
      const requested = params?.protocolVersion;
      const protocolVersion = SUPPORTED_PROTOCOL_VERSIONS.includes(requested) ? requested : PROTOCOL_VERSION;
      reply(id, { protocolVersion, capabilities: { tools: {} }, serverInfo: SERVER_INFO });
      return;
    }
    case 'notifications/initialized':
      return;
    case 'tools/list':
      reply(id, { tools: [ROUTE_TOOL, TOOL] });
      return;
    case 'tools/call': {
      const name = params?.name;

      if (name === 'route_task') {
        const args = params?.arguments || {};
        const defaultProvider = loadConfig().defaults.provider;
        const result = Array.isArray(args.tasks) && args.tasks.length
          ? routeTasks(args.tasks, { defaultProvider })
          : routeTask(args.task || '', { defaultProvider });
        const summary = Array.isArray(args.tasks) && args.tasks.length
          ? `${result.delegate}/${result.total} task(s) delegable` +
            (result.delegatedPayloadChars ? `, ${result.delegatedPayloadChars} chars kept out of context` : '')
          : `${result.decision.toUpperCase()} (confidence ${result.confidence}, score ${result.score})\n` +
            (result.suggestedProvider ? `suggested provider: ${result.suggestedProvider}\n` : '') +
            `advice: ${result.advice}\nwhy:\n  ${result.reasons.join('\n  ') || '(no strong signals)'}`;
        reply(id, { content: [{ type: 'text', text: summary }], isError: false, _meta: { structured: result } });
        return;
      }

      if (name !== 'ask_web_ai') {
        replyError(id, -32602, `Unknown tool: ${name}`);
        return;
      }
      const args = params?.arguments || {};
      try {
        const result = await askWebAI({
          prompt: args.prompt,
          provider: args.provider,
          timeoutMs: args.timeout_ms,
          attachments: args.attachments,
          logLevel: process.env.AWA_LOG_LEVEL || 'info',
        });
        const text = result.status === 'success' ? result.answer : `ERROR (${result.code}): ${result.error}`;
        reply(id, {
          content: [{ type: 'text', text }],
          isError: result.status !== 'success',
          _meta: { structured: result },
        });
      } catch (err) {
        reply(id, { content: [{ type: 'text', text: `ERROR: ${err.message}` }], isError: true });
      }
      return;
    }
    case 'ping':
      reply(id, {});
      return;
    default:
      if (id !== undefined) replyError(id, -32601, `Method not found: ${method}`);
  }
}

// Read newline-delimited JSON-RPC from stdin.
let buffer = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', (chunk) => {
  buffer += chunk;
  let idx;
  while ((idx = buffer.indexOf('\n')) >= 0) {
    const line = buffer.slice(0, idx).trim();
    buffer = buffer.slice(idx + 1);
    if (!line) continue;
    let msg;
    try {
      msg = JSON.parse(line);
    } catch {
      process.stderr.write(`[mcp] bad JSON line: ${line.slice(0, 120)}\n`);
      continue;
    }
    handle(msg).catch((err) => {
      process.stderr.write(`[mcp] handler error: ${err.message}\n`);
      if (msg?.id !== undefined) replyError(msg.id, -32603, err.message);
    });
  }
});

process.stderr.write(`[mcp] free-web-ai-worker ready (providers: ${knownProviderIds().join(', ')})\n`);

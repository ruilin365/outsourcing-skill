/**
 * WebAIProvider base class.
 *
 * A provider knows how to talk to ONE web AI chat site. The main agent never
 * sees any of this — it only calls askWebAI(prompt, provider).
 *
 * Subclasses implement the four site-specific steps:
 *   isLoggedIn(page)   -> detect login wall / signed-out state
 *   findInput(page)    -> locate the prompt composer
 *   submit(page, text) -> type the prompt and press send
 *   extractAnswer(page, baseline) -> read the finished answer text
 *
 * Everything else (timeouts, stability polling, result shape, logging) lives
 * here so providers stay small and selector changes stay localised.
 */

import { ErrorCodes, WebAIError, toWebAIError } from './errors.js';
import { log, stopwatch } from './logger.js';

/** page.url() that never throws (the page may already be closed). */
function safePageUrl(page) {
  try {
    return page?.url ? page.url() : undefined;
  } catch {
    return undefined;
  }
}

export class WebAIProvider {
  /**
   * @param {string} id  provider key from config (e.g. 'gemini')
   * @param {object} settings provider config block
   * @param {object} config   full resolved config
   */
  constructor(id, settings, config) {
    this.id = id;
    this.settings = settings;
    this.config = config;
    this.url = settings.url;
    /** Selector lists live on the subclass; see providers/*.js */
    this.selectors = this.constructor.selectors || {};
  }

  /** Human readable name for logs / results. */
  get displayName() {
    return this.settings.displayName || this.id;
  }

  // ---- to be implemented by subclasses -----------------------------------

  /** @returns {Promise<boolean>} true when the site looks usable (signed in). */
  async isLoggedIn() {
    throw new WebAIError(`${this.id}: isLoggedIn() not implemented`, ErrorCodes.INTERNAL);
  }

  /** @returns {Promise<import('playwright-core').Locator|null>} */
  async findInput() {
    throw new WebAIError(`${this.id}: findInput() not implemented`, ErrorCodes.INTERNAL);
  }

  /** Type the prompt and trigger send. */
  async submit() {
    throw new WebAIError(`${this.id}: submit() not implemented`, ErrorCodes.INTERNAL);
  }

  /**
   * @param {object} baseline snapshot taken before submitting
   * @returns {Promise<string>} final answer text
   */
  async extractAnswer() {
    throw new WebAIError(`${this.id}: extractAnswer() not implemented`, ErrorCodes.INTERNAL);
  }

  // ---- shared helpers ----------------------------------------------------

  /**
   * Return the first selector in `list` that matches, waiting a little for
   * each. Sites love shuffling DOM around, so every provider keeps 3-6
   * fallbacks and we take whichever appears first.
   *
   * @param {import('playwright-core').Page} page
   * @param {string[]} list
   * @param {{timeout?:number, requireVisible?:boolean, scope?:import('playwright-core').Locator}} [opts]
   */
  async firstMatch(page, list, opts = {}) {
    const { timeout = 8000, requireVisible = true, scope = null } = opts;
    for (const selector of list) {
      try {
        const locator = scope ? scope.locator(selector).first() : page.locator(selector).first();
        await locator.waitFor({ state: requireVisible ? 'visible' : 'attached', timeout });
        return locator;
      } catch {
        continue;
      }
    }
    return null;
  }

  /** Count how many answer blocks exist right now (used as a baseline). */
  async countAnswers(page) {
    const selector = this.selectors.ANSWER_COUNT || this.selectors.ANSWER;
    if (!selector) return 0;
    try {
      return await page.locator(selector).count();
    } catch {
      return 0;
    }
  }

  /** Is the "stop generating" control currently visible? */
  async isGenerating(page) {
    const list = this.selectors.STOP_BUTTON || [];
    for (const selector of list) {
      try {
        const el = page.locator(selector).first();
        if (await el.isVisible({ timeout: 250 })) return true;
      } catch {
        continue;
      }
    }
    return false;
  }

  /** Text of the newest answer block, or '' when unreadable. */
  async readLatestAnswer(page) {
    const list = this.selectors.ANSWER || [];
    for (const selector of list) {
      try {
        const all = page.locator(selector);
        const n = await all.count();
        if (n === 0) continue;
        const text = await all.nth(n - 1).innerText({ timeout: 2000 });
        if (text && text.trim()) return text.trim();
      } catch {
        continue;
      }
    }
    return '';
  }

  /**
   * Detect a human-verification challenge (CAPTCHA).
   *
   * We NEVER attempt to solve or bypass these. Detection exists only so the
   * call fails fast with a clear, actionable message: "open the browser window
   * and complete the challenge yourself, then retry".
   */
  async detectCaptcha(page) {
    const list = this.selectors.CAPTCHA || [];
    for (const selector of list) {
      try {
        if (await page.locator(selector).first().isVisible({ timeout: 500 })) return true;
      } catch {
        continue;
      }
    }
    return false;
  }

  /**
   * Detect a network-level block / rate-limit interstitial.
   *
   * Google serves https://www.google.com/sorry/... when it decides a network
   * looks abusive. We never try to evade this: the call fails fast with an
   * actionable message so the caller can switch provider or wait.
   */
  async detectAccessBlocked(page) {
    let url = '';
    try {
      url = page.url();
    } catch {
      return false;
    }
    const urlSignals = [/google\.com\/sorry/i, /\/sorry\//i, /\/cdn-cgi\/challenge/i, /captcha-delivery\.com/i];
    if (urlSignals.some((r) => r.test(url))) return true;

    const textSignals = this.selectors.BLOCK_WALL_TEXT || [
      'text=检测到您的计算机网络中存在异常流量',
      'text=unusual traffic from your computer network',
      'text=unusual traffic',
      'text=Too Many Requests',
    ];
    const bodyText = await page
      .evaluate(() => (document.body?.innerText || '').slice(0, 4000))
      .catch(() => '');
    if (/异常流量|unusual traffic from your computer network/i.test(bodyText)) return true;

    for (const selector of textSignals) {
      try {
        if (await page.locator(selector).first().isVisible({ timeout: 300 })) return true;
      } catch {
        continue;
      }
    }
    return false;
  }

  /**
   * Detect a login wall generically. Providers may override with extra logic.
   * We deliberately do NOT try to defeat the wall - we just report it.
   */
  async detectLoginWall(page) {
    // URL patterns are the most reliable signal across SPA rebuilds.
    try {
      const url = page.url();
      const patterns = this.selectors.LOGIN_URL || [];
      for (const p of patterns) {
        if (typeof p === 'string' ? url.includes(p) : p.test(url)) return true;
      }
    } catch {
      /* ignore */
    }

    const list = this.selectors.LOGIN_WALL || [];
    for (const selector of list) {
      try {
        if (await page.locator(selector).first().isVisible({ timeout: 400 })) return true;
      } catch {
        continue;
      }
    }
    return false;
  }

  /**
   * The full ask flow shared by every provider.
   *
   * @param {import('playwright-core').Page} page
   * @param {string} prompt
   * @param {{timeoutMs:number, stableMs:number, pollMs:number, newChat:boolean, signal:AbortSignal, attachments?:string[]}} opts
   * @returns {Promise<{answer:string, url:string, elapsedMs:number}>}
   */
  async ask(page, prompt, opts) {
    const { timeoutMs, stableMs, pollMs, newChat, signal, attachments } = opts;
    const sw = stopwatch();
    // Use the caller's overall deadline when provided (askWebAI computes one so
    // that browser launch + navigation + answer wait share a single budget);
    // otherwise fall back to a local timeout for direct provider use.
    const deadline = Number(opts.deadline) || Date.now() + timeoutMs;
    const outOfBudget = (stage) => {
      if (!signal?.aborted && Date.now() < deadline) return;
      throw new WebAIError(
        `${this.displayName}: the overall timeout (${Math.round(timeoutMs / 1000)}s) was reached during "${stage}". ` +
          'Raise --timeout, or check the failure artifacts for the page state.',
        ErrorCodes.TIMEOUT,
        { provider: this.id, stage, url: safePageUrl(page) },
      );
    };

    if (!(await this.isLoggedIn(page))) {
      throw new WebAIError(
        `${this.displayName} is not signed in. Open the browser window and log in once; the session is stored in the dedicated Chrome profile and reused afterwards.`,
        ErrorCodes.LOGIN_REQUIRED,
        { provider: this.id, url: this.url, loginUrl: this.url },
      );
    }

    outOfBudget('login check');

    if (await this.detectAccessBlocked(page)) {
      throw new WebAIError(
        `${this.displayName} is refusing requests from this network right now (rate limit / abuse filter). ` +
          'This project never bypasses such blocks. Wait and retry later, or use a different provider (e.g. duckai, qwen).',
        ErrorCodes.ACCESS_BLOCKED,
        { provider: this.id, url: page.url(), suggestion: 'Retry later or switch provider' },
      );
    }

    if (await this.detectCaptcha(page)) {
      throw new WebAIError(
        `${this.displayName} is showing a human-verification challenge. This project never bypasses CAPTCHAs. ` +
          'Open the visible browser window, complete the challenge yourself, then run the same command again.',
        ErrorCodes.CAPTCHA_REQUIRED,
        { provider: this.id, url: page.url(), manualAction: 'Solve the CAPTCHA in the open Chrome window' },
      );
    }

    // Optionally start a fresh conversation so a previous thread cannot leak in.
    if (newChat !== false) {
      await this.startNewChat(page).catch(() => {});
    }

    const input = await this.findInput(page);
    if (!input) {
      throw new WebAIError(
        `Could not find the prompt input on ${this.displayName}. The page layout may have changed.`,
        ErrorCodes.SELECTORS_STALE,
        { provider: this.id, url: safePageUrl(page) },
      );
    }
    outOfBudget('finding the input box');

    // Hand any files to the composer before typing. Text-only providers simply
    // declare no ATTACH selectors, in which case this is a no-op.
    if (attachments?.length) {
      const { attached } = await this.attachFiles(page, attachments);
      if (!attached) {
        throw new WebAIError(
          `${this.displayName}: could not attach the file(s) — the site may expect a different attach control, or does not accept uploads. ` +
            'See the failure artifacts for the page state.',
          ErrorCodes.ATTACHMENT_FAILED,
          { provider: this.id, url: safePageUrl(page), files: attachments.length },
        );
      }
    }

    const baseline = await this.captureBaseline(page);
    log.debug('Submitting prompt', { provider: this.id, baseline, chars: prompt.length });

    try {
      await this.submit(page, prompt, input);
    } catch (err) {
      throw toWebAIError(err, ErrorCodes.SUBMIT_FAILED);
    }

    const answer = await this.waitForAnswer(page, { deadline, stableMs, pollMs, baseline, signal });
    const text = this.postProcess(answer);

    if (!text) {
      throw new WebAIError(`Answer extracted from ${this.displayName} was empty`, ErrorCodes.EXTRACTION_FAILED, { provider: this.id });
    }

    return { answer: text, url: page.url(), elapsedMs: sw.elapsed() };
  }

  /** Hook for subclasses to strip UI chrome / citation noise. */
  postProcess(text) {
    return (text || '').trim();
  }

  /**
   * Snapshot state before submitting so we can detect the *new* answer.
   *
   * We record both the number of answer blocks AND the text of the latest one.
   * The text matters when resuming an existing conversation: the previous
   * answer is already rendered, so "the latest block is non-empty" is not a
   * signal that our new answer has arrived.
   */
  async captureBaseline(page) {
    const answerCount = await this.countAnswers(page).catch(() => 0);
    const lastText = await this.readLatestAnswer(page).catch(() => '');
    return { answerCount, lastText: lastText || '' };
  }

  /**
   * Poll until a new answer appears and its text stops changing.
   * This is the single most failure-prone part of web UI automation, so the
   * logic is intentionally conservative:
   *   1. wait for a new answer block (count grows) OR the last block's text to change
   *   2. require `stableMs` of no change AND no stop/streaming control visible
   */
  async waitForAnswer(page, { deadline, stableMs, pollMs, baseline, signal }) {
    const waitStart = Date.now();
    let lastText = '';
    let stableSince = 0;
    let sawNew = false;
    let polls = 0;

    // Polling reads the page and every read is a request the site can see, so
    // we deliberately poll LESS than the configured base rate: 1.2x-2.4x the
    // poll time (600-1200ms by default). Answer detection still feels instant
    // because completion is confirmed by a stability window, not by the tick.
    // This is purely demand reduction - it does not disguise anything.
    const nextDelay = () => {
      const base = Math.max(500, pollMs);
      const factor = 1.2 + Math.random() * 1.2;
      return Math.round(base * factor);
    };

    while (Date.now() < deadline && !signal?.aborted) {
      if (polls++ === 0) log.info('Waiting for answer...', { provider: this.id });
      await new Promise((r) => setTimeout(r, nextDelay()));

      // Cheap first: only read the DOM when we have reason to.
      const count = await this.countAnswers(page);
      const generating = await this.isGenerating(page);
      const text = await this.readLatestAnswer(page);

      const countGrew = count > (baseline?.answerCount ?? 0);
      // Comparing against the pre-submit baseline (not against the previous
      // poll) is what makes resuming an existing conversation work: there the
      // latest block already holds the *previous* answer, so a non-empty or
      // changed-vs-last-poll text would otherwise be mistaken for our new answer
      // and the stale text returned.
      const textChangedFromBaseline = !!text && text !== (baseline?.lastText ?? '');
      if (countGrew || textChangedFromBaseline) sawNew = true;
      if (!sawNew) {
        if (polls % 20 === 0) log.info('Still waiting for the answer to start...', { provider: this.id, waitedSeconds: Math.round((Date.now() - waitStart) / 1000) });
        continue;
      }

      if (text && text === lastText && !generating) {
        if (stableSince === 0) stableSince = Date.now();
        if (Date.now() - stableSince >= stableMs) {
          log.info('Answer complete', { provider: this.id, chars: text.length });
          return text;
        }
      } else {
        stableSince = 0;
      }
      lastText = text;
    }

    if (lastText) {
      log.warn('Answer arrived but never fully stabilised before the deadline; returning last snapshot', {
        provider: this.id,
        chars: lastText.length,
      });
      return lastText;
    }
    throw new WebAIError(
      `${this.displayName} did not produce an answer before the deadline (${Math.round((Date.now() - waitStart) / 1000)}s elapsed` +
        `${signal?.aborted ? ', call aborted' : ''}). ` +
        'See the artifacts folder for a screenshot of the page state at the time of failure.',
      ErrorCodes.TIMEOUT,
      { provider: this.id, url: safePageUrl(page), waitedSeconds: Math.round((Date.now() - waitStart) / 1000) },
    );
  }

  /**
   * Type text into a contenteditable/textarea and submit — then VERIFY it left.
   *
   * Strategy, in order:
   *   - <textarea> composers (DeepSeek, Qwen, …) submit on Enter, so press Enter
   *     first. This avoids clicking a send button that may be the wrong control
   *     (a resumed thread's page carries extra buttons: attach, mic, and even a
   *     previous message's edit "发送/取消"), which silently sends nothing.
   *   - contenteditable composers keep the button-first path, since Enter there
   *     often inserts a newline instead of sending.
   *   - Every attempt is confirmed by checking the composer actually cleared; if
   *     it did not, the next method is tried.
   */
  async submit(page, prompt, input) {
    await this.setInputText(page, input, prompt);

    // Verify the prompt really landed before sending. Without this, a partially
    // typed prompt (editor quirk, focus loss, paste blocked) is sent as-is and
    // the wrong answer looks like a valid one.
    if (!(await this.inputHasText(input, prompt))) {
      throw new WebAIError(
        `${this.displayName}: the prompt did not appear in the composer, so nothing was sent. ` +
          'The input element may behave differently than expected; see the failure artifacts.',
        ErrorCodes.SUBMIT_FAILED,
        { provider: this.id, url: safePageUrl(page) },
      );
    }

    const pressEnter = async (waitMs) => {
      await input.press('Enter').catch(() => {});
      return this.awaitSent(input, prompt, waitMs);
    };
    const clickSend = async (waitMs) => {
      // Chat SPAs enable the send button a tick after the framework sees input.
      const button = await this.findSendButton(page, input);
      if (!button) return false;
      const enabled = await this.waitForEnabled(button, 6000);
      if (!enabled) {
        log.debug('Send button stayed disabled', { provider: this.id });
        return false;
      }
      await button.click({ timeout: 10000 }).catch(() => {});
      return this.awaitSent(input, prompt, waitMs);
    };

    const isTextarea = await input.evaluate((el) => el.tagName === 'TEXTAREA').catch(() => false);

    let sent = false;
    if (isTextarea) {
      sent = await pressEnter(2500);
      if (!sent) sent = await clickSend(2000);
      if (!sent) sent = await pressEnter(2500);
    } else {
      sent = await clickSend(2000);
      if (!sent) sent = await pressEnter(2500);
    }

    if (!sent) {
      log.warn('Could not confirm the composer cleared after submitting; still waiting for an answer', { provider: this.id });
    }
  }

  /**
   * Did the composer clear — i.e. did our message actually leave?
   *
   * Sites clear (or swap) the composer the moment a send is accepted, so a
   * composer that no longer holds the start of our prompt is the most reliable
   * "it was sent" signal we have without reading the message list.
   */
  async awaitSent(input, prompt, timeoutMs) {
    const marker = String(prompt || '').replace(/\s+/g, '').slice(0, 24);
    const deadline = Date.now() + timeoutMs;
    do {
      const now = await input
        .evaluate((el) => (el.isContentEditable ? el.innerText : el.value) || '')
        .catch(() => '');
      const flat = String(now).replace(/\s+/g, '');
      if (!flat || !flat.includes(marker)) return true;
      await new Promise((r) => setTimeout(r, 200));
    } while (Date.now() < deadline);
    return false;
  }

  /** Wait until a control becomes clickable. Returns false instead of throwing. */
  async waitForEnabled(locator, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        if (await locator.isEnabled({ timeout: 500 })) return true;
      } catch {
        return false;
      }
      await new Promise((r) => setTimeout(r, 200));
    }
    return false;
  }

  /**
   * Robustly place text into an input.
   *
   * Verified 2026-09-19 on Edge 153: Playwright's fill() sets the DOM value but
   * React does not observe it, so the site keeps its send button disabled. Real
   * keyboard input does fire the events these SPAs listen for, which is why the
   * keyboard path is the primary strategy and fill() is only a fallback.
   */
  async setInputText(page, input, prompt) {
    await input.click({ timeout: 10000 });

    // Primary: real keystrokes (works for both <textarea> and contenteditable).
    await this.clearInput(page, input);
    await page.keyboard.insertText(prompt);
    if (await this.inputHasText(input, prompt)) return;

    // Fallback: fill(), for the rare editor that ignores synthetic keys.
    try {
      await input.fill(prompt, { timeout: 5000 });
      if (await this.inputHasText(input, prompt)) return;
    } catch {
      /* fall through */
    }

    // Last resort: set the value directly and notify the framework.
    await input.evaluate((el, text) => {
      el.focus();
      if (el.isContentEditable) {
        el.textContent = text;
      } else {
        el.value = text;
      }
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
    }, prompt);
  }

  /** Clear whatever is currently in the composer. */
  async clearInput(page, input) {
    try {
      await input.evaluate((el) => {
        el.focus();
        if (el.isContentEditable) el.textContent = '';
        else el.value = '';
      });
    } catch {
      /* ignore */
    }
    await page.keyboard.press('Control+A').catch(() => {});
    await page.keyboard.press('Delete').catch(() => {});
    await page.waitForTimeout(150);
  }

  /**
   * Is there text in the composer now?
   *
   * Note: we only require *some* text, not an exact match. Rich editors
   * normalise whitespace and emoji, so an exact comparison produces false
   * negatives that would push us into the fallback path unnecessarily.
   */
  async inputHasText(input, expected) {
    try {
      const raw = await input.evaluate((el) => (el.isContentEditable ? el.innerText : el.value) || '');
      const got = String(raw);
      if (!got.trim()) return false;

      const wanted = String(expected ?? '').trim();
      if (!wanted) return true;

      // Editors reflow whitespace, so compare with whitespace removed.
      const norm = (s) => s.replace(/\s+/g, '');
      const a = norm(got);
      const b = norm(wanted);
      if (!a) return false;

      // A short prompt must be present in full.
      if (b.length <= 120) return a === b || a.includes(b);

      // A long prompt: require BOTH ends to be present. This tolerates an editor
      // that shows a collapsed view of the middle, while still catching a
      // partially typed prompt (whose tail would be missing).
      return a.includes(b.slice(0, 60)) && a.includes(b.slice(-40));
    } catch {
      return false;
    }
  }

  /** Subclasses declare SEND_BUTTON selector lists. */
  async findSendButton(page, input) {
    const selectors = this.selectors.SEND_BUTTON || [];
    if (!selectors.length) return null;

    // Prefer a send control INSIDE the composer (a close ancestor of the input).
    // We take the LAST match in the row because attach / mic icons precede the
    // send button, so "last" avoids grabbing the paperclip. This matters most on
    // a resumed thread, whose page also carries a previous message's edit
    // "发送 / 取消" buttons — the global search would otherwise hit those.
    if (input) {
      for (let level = 1; level <= 5; level++) {
        let ancestor;
        try {
          ancestor = input.locator(`xpath=ancestor::*[${level}]`);
          if ((await ancestor.count()) === 0) break;
        } catch {
          break;
        }
        for (const sel of selectors) {
          try {
            const cand = ancestor.locator(sel);
            const n = await cand.count();
            if (n > 0) return cand.nth(n - 1);
          } catch {
            /* try the next selector */
          }
        }
      }
    }
    return this.firstMatch(page, selectors, { timeout: 4000 });
  }

  /**
   * Start a fresh conversation.
   *
   * A new tab opened at the site root is already a new chat for most sites, but
   * some SPAs restore the previous thread instead. When the site exposes an
   * explicit "new chat" control (declared as NEW_CHAT selectors) we click it;
   * otherwise we leave the page as opened. Kept to a single short lookup so it
   * does not slow the common path.
   *
   * @returns {Promise<boolean>} true when a new-chat control was clicked
   */
  async startNewChat(page) {
    const list = (this.selectors.NEW_CHAT || []).filter((s) => typeof s === 'string' && !s.startsWith('text='));
    if (!list.length) return false;
    try {
      const el = page.locator(list.join(', ')).first();
      await el.waitFor({ state: 'visible', timeout: 1200 });
      await el.click({ timeout: 4000 });
      await page.waitForTimeout(400);
      log.debug('Started a new conversation', { provider: this.id });
      return true;
    } catch {
      log.debug('No new-chat control found (or it was not clickable); using the page as opened', { provider: this.id });
      return false;
    }
  }

  /**
   * Hand local files to the composer.
   *
   * Two-step, because sites differ: some keep a real `<input type="file">` in
   * the DOM (often hidden), others only create it after the paperclip / "+"
   * button is clicked. We try the input first, then the button.
   *
   * Playwright's setInputFiles drives the native file chooser, so this is the
   * same path a human takes — no synthetic drops, no clickjacking.
   *
   * @param {import('playwright-core').Page} page
   * @param {string[]} filePaths absolute paths
   * @returns {Promise<{attached:number}>}
   */
  async attachFiles(page, filePaths) {
    const files = (filePaths || []).filter(Boolean);
    if (!files.length) return { attached: 0 };

    const inputs = this.selectors.ATTACH_INPUT || ['input[type="file"]'];
    const trySet = async () => {
      for (const sel of inputs) {
        try {
          const loc = page.locator(sel).first();
          if ((await loc.count()) === 0) continue;
          await loc.setInputFiles(files, { timeout: 8000 });
          return true;
        } catch {
          /* try the next candidate */
        }
      }
      return false;
    };

    // A human clicks the paperclip first, and several SPAs only arm their file
    // input once the attach control has been used. Try that order first, then
    // fall back to a direct set for sites that keep the input live.
    const button = await this.firstMatch(page, this.selectors.ATTACH_BUTTON || [], { timeout: 2000 });
    let ok = false;
    if (button) {
      await button.click({ timeout: 5000 }).catch(() => {});
      await page.waitForTimeout(700);
      ok = await trySet();
    }
    if (!ok) ok = await trySet();
    if (!ok) return { attached: 0 };

    // Let the SPA process the file and render its preview before we submit.
    await page.waitForTimeout(1500);

    // A site can silently reject the upload — most often because the account is
    // signed out: it resets the <input type=file> and renders no preview. The
    // message would then go out with no attachment and we would return a bogus
    // answer (observed on Qwen guest mode). Fail loudly instead.
    if (!(await this.attachmentAccepted(page, files))) {
      log.warn('The site did not show the attachment — it was likely rejected (signed out?).', { provider: this.id });
      return { attached: 0 };
    }

    log.info('Attached files to the composer', { provider: this.id, files: files.length });
    return { attached: files.length };
  }

  /**
   * Heuristic: did the site actually take the file?
   *
   * True when a preview appeared (a blob:/data: image) or the file name is
   * shown in the page. Errs towards "accepted" if the probe itself fails, so a
   * DOM quirk can never block a site that otherwise works.
   */
  async attachmentAccepted(page, filePaths) {
    const names = (filePaths || []).map((f) => String(f).split(/[\\/]/).pop()).filter(Boolean);
    try {
      return await page.evaluate((basenames) => {
        const imgs = Array.from(document.querySelectorAll('img'));
        if (imgs.some((i) => /^(blob|data):/.test(i.getAttribute('src') || ''))) return true;
        const text = document.body ? document.body.innerText || '' : '';
        return basenames.some((n) => n && text.includes(n));
      }, names);
    } catch {
      return true;
    }
  }
}








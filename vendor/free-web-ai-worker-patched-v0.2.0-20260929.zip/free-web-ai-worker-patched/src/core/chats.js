/**
 * A tiny per-machine registry of *named* web-AI conversations.
 *
 * Why this exists
 * ---------------
 * Every provider's home URL (e.g. https://chat.deepseek.com/) opens a BRAND NEW
 * conversation when you navigate to it. So "continue the previous chat" is
 * impossible unless you remember the conversation's own URL and navigate back
 * to it. This module stores a friendly name -> { url, provider, updatedAt }
 * mapping in `~/.agent-web-ai/chats.json` so an agent can:
 *
 *   - create + name a conversation once   (ask --session todo-html)
 *   - resume it on every later run        (ask --session todo-html)
 *   - rename / list / delete it           (ask-web-ai chats ...)
 *
 * The registry is deliberately independent of any single provider's UI so it
 * keeps working even if a site renames its sidebar controls.
 */

import { readFileSync, existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { writeJsonAtomic } from './atomic.js';

export function chatsPath() {
  return join(homedir(), '.agent-web-ai', 'chats.json');
}

/** Read the whole registry as a plain object (never throws). */
export function readAll() {
  const p = chatsPath();
  if (!existsSync(p)) return {};
  try {
    const data = JSON.parse(readFileSync(p, 'utf8'));
    return data && typeof data === 'object' && !Array.isArray(data) ? data : {};
  } catch {
    return {};
  }
}

function writeAll(data) {
  writeJsonAtomic(chatsPath(), data);
}

/** @returns {{url:string, provider?:string, title?:string, updatedAt?:string}|null} */
export function getChat(name) {
  if (!name) return null;
  return readAll()[String(name)] || null;
}

/** Create or update an entry; returns the stored record. */
export function putChat(name, patch) {
  const all = readAll();
  const prev = all[name] || {};
  all[name] = { ...prev, ...patch, updatedAt: new Date().toISOString() };
  writeAll(all);
  return all[name];
}

/** @returns {boolean} whether an entry existed. */
export function removeChat(name) {
  const all = readAll();
  const existed = Object.prototype.hasOwnProperty.call(all, name);
  delete all[name];
  writeAll(all);
  return existed;
}

/** @returns {boolean} whether the old name existed. */
export function renameChat(oldName, newName) {
  const all = readAll();
  if (!Object.prototype.hasOwnProperty.call(all, oldName)) return false;
  all[newName] = { ...all[oldName], renamedFrom: oldName, updatedAt: new Date().toISOString() };
  delete all[oldName];
  writeAll(all);
  return true;
}

/** All entries, oldest-updated first (stable, readable order). */
export function listChats() {
  return Object.entries(readAll())
    .map(([name, v]) => ({ name, ...v }))
    .sort((a, b) => String(a.updatedAt || '').localeCompare(String(b.updatedAt || '')));
}

/**
 * Atomic file writes.
 *
 * Why: this tool is invoked as a short-lived process (each CLI call is a new
 * process, and an agent may run several in parallel). Writing state with a
 * plain writeFileSync can leave a half-written file behind if two writers
 * overlap, which then fails to parse on the next read. Writing to a unique
 * temp file in the same directory and renaming it over the target is atomic
 * on both POSIX and Windows (Node's rename replaces the destination).
 */

import { mkdirSync, writeFileSync, renameSync, rmSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { randomBytes } from 'node:crypto';

/**
 * Write `data` to `filePath` atomically.
 * @param {string} filePath
 * @param {string|Buffer} data
 */
export function writeFileAtomic(filePath, data) {
  mkdirSync(dirname(filePath), { recursive: true });
  const tmp = join(dirname(filePath), `.${process.pid}.${randomBytes(6).toString('hex')}.tmp`);
  try {
    writeFileSync(tmp, data);
    renameSync(tmp, filePath);
  } catch (err) {
    // Clean up the temp file so a failure never leaves litter behind.
    try {
      rmSync(tmp, { force: true });
    } catch {
      /* ignore */
    }
    throw err;
  }
}

/** Serialise `value` as pretty JSON and write it atomically. */
export function writeJsonAtomic(filePath, value) {
  writeFileAtomic(filePath, JSON.stringify(value, null, 2) + '\n');
}

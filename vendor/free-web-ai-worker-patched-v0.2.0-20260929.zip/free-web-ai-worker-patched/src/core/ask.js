/**
 * askWebAI — the single public entry point of this project.
 *
 *   const result = await askWebAI({ prompt, provider });
 *   // success: { status:'success', provider, answer, meta }
 *   // error:   { status:'error',   provider, error, code }
 *
 * Design notes
 *   - Always returns a structured object; it never throws for expected errors.
 *     Agents consuming this are bad at try/catch and good at reading JSON.
 *   - Never bypasses logins/CAPTCHAs/rate limits. If a site wants a human, we
 *     report it and stop. Throttling makes us quieter, never pushier.
 *   - One browser, one tab per call: cheap, isolated, no cross-prompt leakage.
 *   - Answer cache + per-provider throttle sit in front of the browser so that
 *     repeated or rapid use cannot turn into an abusive traffic pattern.
 */

import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { loadConfig } from './config.js';
import { ErrorCodes, WebAIError, toWebAIError } from './errors.js';
import { configureLogger, log } from './logger.js';
import { ensureBrowser, detach, openPage, resolveBrowser, profileDirFor } from './browser.js';
import { getChat, putChat } from './chats.js';
import { captureFailure } from './artifacts.js';
import { checkAllowed, recordSuccess, recordAttempt, recordBlock } from './throttle.js';
import { cacheGet, cachePut } from './cache.js';
import { createProvider, knownProviderIds } from '../providers/index.js';

function normaliseAttachments(list) {
  if (!list) return [];
  const arr = Array.isArray(list) ? list : [list];
  const out = [];
  for (const p of arr) {
    if (typeof p !== 'string' || !p.trim()) continue;
    const abs = resolve(p);
    if (!existsSync(abs)) {
      throw new WebAIError(`Attachment not found: ${abs}`, ErrorCodes.INVALID_INPUT, { path: abs });
    }
    out.push(abs);
  }
  return out;
}

function normaliseOptions(options) {
  const cfg = loadConfig();
  const o = options || {};
  const attachments = normaliseAttachments(o.attachments);
  let prompt = typeof o.prompt === 'string' ? o.prompt : '';
  if (!prompt.trim()) {
    if (attachments.length) {
      // An attachment with no instruction still deserves a sensible default.
      prompt = '请阅读并处理附件内容，把主要内容转成文字。';
    } else {
      throw new WebAIError('prompt must be a non-empty string', ErrorCodes.INVALID_INPUT);
    }
  }

  const provider = (o.provider || cfg.defaults.provider || 'duckai').toLowerCase();
  if (!knownProviderIds().includes(provider)) {
    throw new WebAIError(
      `Unknown provider "${provider}". Known providers: ${knownProviderIds().join(', ')}`,
      ErrorCodes.UNKNOWN_PROVIDER,
      { knownProviders: knownProviderIds() },
    );
  }

  const settings = cfg.providers?.[provider] || {};
  if (settings.enabled === false) {
    throw new WebAIError(`Provider "${provider}" is disabled in config`, ErrorCodes.PROVIDER_DISABLED, { provider });
  }

  const timeoutMs = Number(o.timeoutMs ?? cfg.defaults.timeoutMs);
  const stableMs = Number(o.stableMs ?? cfg.defaults.stableMs);
  const pollMs = Number(o.pollMs ?? cfg.defaults.pollMs);

  if (!Number.isFinite(timeoutMs) || timeoutMs < 5000) {
    throw new WebAIError('timeoutMs must be a number >= 5000', ErrorCodes.INVALID_INPUT);
  }

  return {
    cfg,
    prompt,
    provider,
    timeoutMs,
    stableMs,
    pollMs,
    logLevel: o.logLevel || cfg.logging.level || 'info',
    dryRun: !!o.dryRun,
    noThrottle: !!o.noThrottle,
    noCache: !!o.noCache,
    newChat: o.newChat ?? (cfg.defaults.newChat !== false),
    attachments,
    cacheTtlSeconds: Number(o.cacheTtlSeconds ?? cfg.cache?.ttlSeconds ?? 3600),
    // Named-conversation support: `session` remembers a conversation by name so
    // later runs land back in the SAME thread; `chatUrl` targets one directly.
    session: typeof o.session === 'string' && o.session.trim() ? o.session.trim() : null,
    chatUrl: typeof o.chatUrl === 'string' && o.chatUrl.trim() ? o.chatUrl.trim() : null,
  };
}

/**
 * @param {object} options
 * @param {string} options.prompt
 * @param {string} [options.provider]      default from config
 * @param {number} [options.timeoutMs]
 * @param {number} [options.stableMs]
 * @param {string} [options.logLevel]      silent|error|warn|info|debug
 * @param {(line:string)=>void} [options.onLog]
 * @param {boolean} [options.dryRun]       resolve config/provider only, no browser
 * @param {boolean} [options.noThrottle]   skip interval/quota/breaker checks
 * @param {boolean} [options.noCache]      bypass the answer cache
 * @param {number}  [options.cacheTtlSeconds]
 * @param {string}  [options.session]      named conversation to create or resume
 * @param {string}  [options.chatUrl]      explicit conversation URL to resume
 * @returns {Promise<object>} structured result — never throws
 */
export async function askWebAI(options = {}) {
  let opts;
  try {
    opts = normaliseOptions(options);
  } catch (err) {
    const e = toWebAIError(err, ErrorCodes.INVALID_INPUT);
    return e.toResult(options?.provider ?? null);
  }

  configureLogger({ level: opts.logLevel, onLine: options.onLog });
  const { cfg, prompt, provider: providerId, timeoutMs } = opts;
  const startedAt = new Date().toISOString();
  const throttleCfg = cfg.throttle;

  // Resolve the profile directory up front — throttle and cache state live there.
  const activeBrowser = resolveBrowser(cfg);
  const profileDir = activeBrowser ? profileDirFor(cfg, activeBrowser.id) : cfg.browser.profileDir;

  log.info('ask_web_ai start', { provider: providerId, chars: prompt.length, timeoutMs });

  if (opts.dryRun) {
    const provider = createProvider(providerId, cfg);
    return { status: 'success', provider: providerId, answer: null, meta: { dryRun: true, url: provider.url, promptChars: prompt.length } };
  }

  // ---- cache ---------------------------------------------------------------
  if (cfg.cache?.enabled !== false && !opts.noCache) {
    const hit = cacheGet(profileDir, providerId, prompt, opts.cacheTtlSeconds, opts.attachments);
    if (hit) {
      log.info('ask_web_ai success (from cache)', { provider: providerId, chars: hit.answer.length });
      return {
        status: 'success',
        provider: providerId,
        answer: hit.answer,
        meta: { ...hit.meta, model: cfg.providers?.[providerId]?.displayName || providerId, startedAt, elapsedMs: 0, chars: hit.answer.length },
      };
    }
  }

  // ---- throttle ------------------------------------------------------------
  if (!opts.noThrottle) {
    const gate = checkAllowed(profileDir, providerId, throttleCfg);
    if (!gate.allowed) {
      log.warn('Call refused by the rate-limit guard', { provider: providerId, reason: gate.reason });
      return {
        status: 'error',
        provider: providerId,
        error: gate.reason,
        code: ErrorCodes.RATE_LIMITED_LOCALLY,
        details: {
          provider: providerId,
          waitSeconds: Math.ceil((gate.waitMs || 0) / 1000) || null,
          remainingToday: gate.remainingToday ?? null,
          suggestion: 'Wait as indicated, use another provider, or lower throttle strictness in config/local.json.',
        },
        meta: { startedAt },
      };
    }
    if (gate.waitMs > 0) {
      log.info(`Waiting ${Math.ceil(gate.waitMs / 1000)}s before calling ${providerId}`, { reason: gate.reason });
      await new Promise((r) => setTimeout(r, gate.waitMs));
    }
  }

  let browser = null;
  let page = null;
  let provider = null;

  // One budget for browser launch + navigation + answer. Previously `timeoutMs`
  // bounded only the answer wait, so a slow launch or navigation could push the
  // real duration far past what the caller asked for. Now the whole call is
  // capped, and the provider stops early when the budget is gone.
  const overallDeadline = Date.now() + timeoutMs;
  const abortController = new AbortController();
  const overallTimer = setTimeout(() => abortController.abort(), timeoutMs);

  try {
    provider = createProvider(providerId, cfg);

    // Decide which conversation to open. A provider's home URL opens a BRAND NEW
    // conversation, so to "continue the earlier one" we must navigate back to
    // that conversation's own URL — either an explicit --chat-url or one we
    // remembered under a session name.
    const knownSession = opts.session ? getChat(opts.session) : null;
    const resumeUrl = opts.chatUrl || knownSession?.url || null;
    const resuming = !!resumeUrl;
    const targetUrl = resumeUrl || provider.url;
    log.info(resuming ? 'Resuming an existing conversation' : 'Opening a fresh conversation', {
      provider: providerId,
      session: opts.session || undefined,
      url: targetUrl,
    });

    const { browser: b, context, browserInfo } = await ensureBrowser(cfg, { initialUrl: targetUrl });
    browser = b;

    // Give navigation whatever is left of the budget (never below 5s).
    const remainingMs = Math.max(5000, overallDeadline - Date.now());
    const navBudgetMs = Math.min(Math.max(30000, Math.min(timeoutMs, 60000)), remainingMs);
    page = await openPage(context, targetUrl, { waitMs: navBudgetMs });
    log.debug('Page opened', { provider: providerId, url: page.url() });

    const { answer, url, elapsedMs } = await provider.ask(page, prompt, {
      timeoutMs,
      stableMs: opts.stableMs,
      pollMs: opts.pollMs,
      deadline: overallDeadline,
      // Never click "new chat" when we deliberately navigated into an existing
      // thread — that would throw away the context we came back for.
      newChat: resuming ? false : opts.newChat,
      signal: abortController.signal,
      attachments: opts.attachments,
    });

    if (!opts.noThrottle) recordSuccess(profileDir, providerId);

    // Remember (or refresh) the conversation URL under its session name so the
    // next run with the same --session lands back here.
    if (opts.session) {
      putChat(opts.session, { url: url || page.url(), provider: providerId });
      log.info('Remembered conversation', { session: opts.session, url: url || page.url() });
    }

    const capped = answer.length > cfg.defaults.maxAnswerChars ? answer.slice(0, cfg.defaults.maxAnswerChars) : answer;
    log.info('ask_web_ai success', { provider: providerId, chars: capped.length, elapsed: `${Math.round(elapsedMs / 1000)}s` });

    const meta = {
      model: cfg.providers?.[providerId]?.displayName || providerId,
      url,
      chars: capped.length,
      truncated: capped.length !== answer.length,
      elapsedMs,
      startedAt,
      browser: browserInfo?.id,
      cached: false,
    };

    if (cfg.cache?.enabled !== false && !opts.noCache) {
      cachePut(profileDir, providerId, prompt, capped, meta, opts.attachments);
    }

    return { status: 'success', provider: providerId, answer: capped, meta };
  } catch (err) {
    const e = toWebAIError(err, ErrorCodes.INTERNAL);
    log.error('ask_web_ai failed', { provider: providerId, code: e.code, error: e.message });

    if (!opts.noThrottle) {
      // A captcha or a network block is the provider telling us to slow down.
      if (e.code === ErrorCodes.CAPTCHA_REQUIRED || e.code === ErrorCodes.ACCESS_BLOCKED) {
        recordBlock(profileDir, providerId, throttleCfg, e.code);
      } else {
        recordAttempt(profileDir, providerId);
      }
    }

    const artifacts = await captureFailure(page, profileDir, providerId, { code: e.code, error: e.message });
    return e.toResult(providerId, {
      meta: { startedAt, url: safeUrl(page), browser: activeBrowser?.id, ...(artifacts ? { artifacts } : {}) },
    });
  } finally {
    clearTimeout(overallTimer);
    if (page) await page.close().catch(() => {});
    if (browser) await detach(browser);
    log.debug('cleanup complete', { provider: providerId });
  }
}

function safeUrl(page) {
  try {
    return page?.url ? page.url() : undefined;
  } catch {
    return undefined;
  }
}

export { ErrorCodes } from './errors.js';
